-- screenSaver widget - image selectable via option
local name = "Images"

-- Widget option: image filename (max 12 chars)
local options = {
  { "Img", STRING, "image1.png" }
}

local bm = nil
local xd, yd, scl
local LCD_W, LCD_H = 480, 272

-- Load image using option value
local function loadImage(filename)
    local path = "/WIDGETS/Images/images/" .. filename
    bm = nil

    local ok, img = pcall(Bitmap.open, path)
    if ok and img then
        bm = img
        local w, h = Bitmap.getSize(bm)
        local wr, hr = LCD_W / w, LCD_H / h
        xd, yd, scl = 0, 0, 100

        if wr < hr then
            scl = math.ceil(wr * 100)
            yd = math.ceil((LCD_H - h * wr) / 2)
        else
            scl = math.ceil(hr * 100)
            xd = math.ceil((LCD_W - w * hr) / 2)
        end
    end
end

local function create(zone, opts)
    loadImage(opts.Img)
    return {
        zone = zone,
        options = opts
    }
end

local function update(widget, opts)
    widget.options = opts
    loadImage(opts.Img) -- reload when option changes
end

local function refresh(widget)
    if bm then
        lcd.drawBitmap(bm, xd, yd, scl)
    else
        lcd.drawText(
            widget.zone.x + 20,
            widget.zone.y + 40,
            "Image not found",
            MIDSIZE
        )
    end
end

return {
    name     = name,
    options  = options,
    create   = create,
    update   = update,
    refresh  = refresh
}
