local name = "Images"

local options = {
  { "Img1", STRING, "image1" },
  { "Img2", STRING, "" },
  { "Img3", STRING, "" },
  { "Img4", STRING, "" },
  { "Img5", STRING, "" },
  { "Img6", STRING, "" },
  { "Img7", STRING, "" },
  { "Img8", STRING, "" },
  { "Select", VALUE, 1, 1, 8 },
  { "Slide", VALUE, 0, 0, 1 }
}

local bm = nil
local xd, yd, scl
local LCD_W, LCD_H = 480, 272
local currentIndex = 1
local lastChangeTime = 0
local SLIDE_INTERVAL = 800 -- 8 seconds

local function normalizeFilename(imgName)
    if not imgName or imgName == "" then return nil end
    if not string.match(string.lower(imgName), "%.png$") then
        imgName = imgName .. ".png"
    end
    return imgName
end

local function loadImage(imgName)
    bm = nil
    if not imgName or imgName == "" then return false end
    local filename = normalizeFilename(imgName)
    local path = "/WIDGETS/Images/images/" .. filename
    local ok, img = pcall(Bitmap.open, path)
    if ok and img then
        bm = img
        local w,h = Bitmap.getSize(bm)
        local wr, hr = LCD_W/w, LCD_H/h
        xd, yd, scl = 0,0,100
        if wr < hr then
            scl = math.ceil(wr*100)
            yd = math.ceil((LCD_H - h*wr)/2)
        else
            scl = math.ceil(hr*100)
            xd = math.ceil((LCD_W - w*hr)/2)
        end
        return true
    end
    return false
end

local function getImageByIndex(opts,index)
    return opts["Img"..index]
end

local function nextValidIndex(opts,startIndex)
    local idx = startIndex
    for _=1,8 do
        idx = idx+1
        if idx>8 then idx=1 end
        local img = getImageByIndex(opts, idx)
        if img and img~="" then return idx end
    end
    return startIndex
end

local function create(zone, opts)
    currentIndex = opts.Select
    lastChangeTime = getTime()
    loadImage(getImageByIndex(opts,currentIndex))
    return { zone=zone, options=opts }
end

local function update(widget, opts)
    widget.options = opts
    currentIndex = opts.Select
    lastChangeTime = getTime()
    loadImage(getImageByIndex(opts,currentIndex))
end

local function refresh(widget)
    local opts = widget.options
    local now = getTime()

    -- Slideshow: advance only if Slide=1 and at least one next image exists
    if opts.Slide==1 and now - lastChangeTime >= SLIDE_INTERVAL then
        lastChangeTime = now
        local nextIdx = nextValidIndex(opts,currentIndex)
        loadImage(getImageByIndex(opts,nextIdx))
        currentIndex = nextIdx
    elseif opts.Slide==0 and currentIndex~=opts.Select then
        currentIndex = opts.Select
        loadImage(getImageByIndex(opts,currentIndex))
    end

    -- DRAW: bitmap or error message
    if bm then
        lcd.drawBitmap(bm, 0, 0, scl)
    else
        lcd.drawText(20, 40, "Image not found", MIDSIZE)
    end
end

return {
    name=name,
    options=options,
    create=create,
    update=update,
    refresh=refresh
}
